import core.*;
import junit.framework.TestCase;
import java.util.*;
import java.util.stream.Collectors;

public class TestRouteCalculator  extends TestCase {

    StationIndex stationIndex = new StationIndex();
    String[] arrNameOfStation = new String[]{"A", "B", "C", "D", "E", "F", "G", "K", "L"};
    String[] arrNameOfLine = new String[] {"black", "white", "brown"};

    private void makeAll (){
        ArrayList<Station> listOfStations = new ArrayList<>();
        int x = 0;
        int k = 0;

        for (int i = 0; i < 3; i++) { stationIndex.addLine(new Line(i, arrNameOfLine[i])); }

        for ( ;x < 3; x++) { stationIndex.getLine(k).addStation(new Station(arrNameOfStation[x], stationIndex.getLine(k))); }
            listOfStations.addAll( stationIndex.getLine(k).getStations());

        for ( ;x < 6; x++) { stationIndex.getLine(k+1).addStation(new Station(arrNameOfStation[x], stationIndex.getLine(k+1))); }
            listOfStations.addAll( stationIndex.getLine(k+1).getStations());

        for ( ;x < 9; x++) { stationIndex.getLine(k+2).addStation(new Station(arrNameOfStation[x], stationIndex.getLine(k+2))); }
            listOfStations.addAll( stationIndex.getLine(k+2).getStations());

        for(int p = 0; p < listOfStations.size(); p++)   { stationIndex.addStation(listOfStations.get(p));}
    }

    RouteCalculator calculator = new RouteCalculator(stationIndex);

     /** d---e---f
     * |      ||                     Black = A - B - C - D
     * c      g                      Brown = F - G - K - L
     * |     ||                      White = D - E - F
     * b     k
     * |    ||
     * a    l   */

    @Override
    protected void setUp() throws Exception {
        makeAll();

        List<Station> connectionStations = new ArrayList<>();
        connectionStations.add(stationIndex.getStation("C"));
        connectionStations.add(stationIndex.getStation("D"));
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();

        connectionStations.add(stationIndex.getStation("F"));
        connectionStations.add(stationIndex.getStation("G"));
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();
    }

        public void testCalculateDuration () {
            List<Station> route = calculator.getShortestRoute(stationIndex.getStation("A"), stationIndex.getStation("C"));
            double actual = RouteCalculator.calculateDuration(route);
            double expected = 5.0;
            assertEquals(expected, actual);
        }

        public void testRouteOnTheLine () {
            List<Station> route = calculator.getShortestRoute(stationIndex.getStation("A"), stationIndex.getStation("C"));
            List<String> expected = Arrays.asList("A", "B", "C");
            assertEquals(expected, route.stream().map(s -> s.getName()).collect(Collectors.toList()));
        }

        public void testRouteWithOneConnection () {
            List<Station> route = calculator.getShortestRoute(stationIndex.getStation("A"), stationIndex.getStation("E"));
            List<String> expected = Arrays.asList("A", "B", "C", "D", "E");
            assertEquals(expected, route.stream().map(s -> s.getName()).collect(Collectors.toList()));
        }

        public void testRouteWithTwoConnections () {
            List<Station> route = calculator.getShortestRoute(stationIndex.getStation("A"), stationIndex.getStation("G"));
            List<String> expected = Arrays.asList("A", "B", "C", "D", "E", "F", "G");
            assertEquals(expected, route.stream().map(s -> s.getName()).collect(Collectors.toList()));
        }
    }