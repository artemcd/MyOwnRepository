import core.Line;
import core.Station;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class TestRouteCalculator  extends TestCase {
    RouteCalculator calculator;
    StationIndex stationIndex;
    Line black;
    Line white;
    Line brown;
    Station a;
    Station z;
    Station e;
    Station d;
    Station k;
    Station b;
    Station c;
    Station f;
    Station g;
    Station n;
    Station p;
    Station m;

    List<Station> route;
    /**             c            Black = a - d - m - p - e - f
    *              ||            White = b - d - k - g - z
    * a----d--m--p-e------f     Brown = c - e - g - n
    *      |      ||
    *      k______g
    *            ||
    *            n
    *
    *
    * */

    @Override
    protected void setUp() throws Exception {

        stationIndex = new StationIndex();

        white = new Line(1, "Белая");
        black = new Line(2, "Черная");
        brown = new Line(3, "Коричнева");

        a = new Station("A", black);
        d = new Station("D", black);
        m = new Station("M", black);
        p = new Station("P", black);
        e = new Station("E", black);
        f = new Station("F", black);


        c = new Station("C", brown);
        g = new Station("G", brown);
        n = new Station("N", brown);

        k = new Station("K", white);

        white.addStation(d);
        white.addStation(k);
        white.addStation(g);

        black.addStation(a);
        black.addStation(d);
        black.addStation(m);
        black.addStation(p);
        black.addStation(e);
        black.addStation(f);



        brown.addStation(c);
        brown.addStation(e);
        brown.addStation(g);
        brown.addStation(n);

        stationIndex.addStation(a);
        stationIndex.addStation(e);
        stationIndex.addStation(d);
        stationIndex.addStation(k);
        stationIndex.addStation(c);
        stationIndex.addStation(f);
        stationIndex.addStation(g);
        stationIndex.addStation(n);
        stationIndex.addStation(m);
        stationIndex.addStation(p);


        stationIndex.addLine(white);
        stationIndex.addLine(black);
        stationIndex.addLine(brown);

        List<Station> connectionStations = new ArrayList<>();
        connectionStations.add(c);
        connectionStations.add(e);
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();

        connectionStations.add(e);
        connectionStations.add(g);
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();

        connectionStations.add(d);
        connectionStations.add(k);
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();

        connectionStations.add(k);
        connectionStations.add(g);
        stationIndex.addConnection(connectionStations);

        calculator = new RouteCalculator(stationIndex);
    }


        public void testCalculateDuration () {
            List<Station> route = calculator.getShortestRoute(d, g);
            double actual = RouteCalculator.calculateDuration(route);
            double expected = 5;
            assertEquals(expected, actual);
        }

        public void testRouteOnTheLine () {
            List<Station> route = calculator.getShortestRoute(a, m);
            List<String> expected = Arrays.asList("A", "D", "M");
            assertEquals(expected, route.stream().map(s -> s.getName()).collect(Collectors.toList()));
        }

        public void testRouteWithOneConnection () {
            List<Station> route = calculator.getShortestRoute(c, f);
            List<String> expected = Arrays.asList("C", "E", "F");
            assertEquals(expected, route.stream().map(s -> s.getName()).collect(Collectors.toList()));
        }

        public void testRouteWithTwoConnections () {
            List<Station> route = calculator.getShortestRoute(a, n);
            List<String> expected = Arrays.asList("A", "D", "K", "G", "N");
            assertEquals(expected, route.stream().map(s -> s.getName()).collect(Collectors.toList()));
        }
    }

