import core.*;
import junit.framework.TestCase;
import java.util.*;
import java.util.stream.Collectors;

public class TestRouteCalculator  extends TestCase {

    StationIndex stationIndex = new StationIndex();
    String[] arrNameOfStation = new String[]{"A", "B", "C", "D", "E", "F", "G", "K", "L"};
    String[] arrNameOfLine = new String[] {"black", "white", "brown"};

    private List<Station> getList (String... arr)   {
        ArrayList <Station> myListOfStations = new ArrayList<>();
        for(String station : arr) {
            if (stationIndex.getStation(station) != null) {
                myListOfStations.add(stationIndex.getStation(station));
            }
        }return myListOfStations;
    }

    private void makeAll (){
        ArrayList <Line> lines = new ArrayList<>();
        ArrayList <Station> listOfMyStations = new ArrayList<>();
        for (int i = 1; i <= 3; i++)   { lines.add(new Line(i, arrNameOfLine[i -1])); }

        for( int i = 0, line = 0; i < 9; i++)   {
            if(i != 0 && i%3 == 0) line++;
            Station temp = new Station(arrNameOfStation[i], lines.get(line));
            listOfMyStations.add(temp);
            lines.get(line).addStation(temp);
            stationIndex.addStation(temp);
        }
        lines.forEach(l -> stationIndex.addLine(l));
    }

    RouteCalculator calculator = new RouteCalculator(stationIndex);

     /** d---e---f
     * |      ||                     Black = A - B - C - D
     * c      g                      Brown = F - G - K - L
     * |     ||                      White = D - E - F
     * b     k
     * |    ||
     * a    l   */

    @Override
    protected void setUp() throws Exception {
        makeAll();

        List<Station> connectionStations = new ArrayList<>();
        connectionStations.add(stationIndex.getStation("C"));
        connectionStations.add(stationIndex.getStation("D"));
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();

        connectionStations.add(stationIndex.getStation("F"));
        connectionStations.add(stationIndex.getStation("G"));
        stationIndex.addConnection(connectionStations);
        connectionStations.clear();
    }

        public void testCalculateDuration () {
            List<Station> route = calculator.getShortestRoute(stationIndex.getStation("A"), stationIndex.getStation("C"));
            double actual = RouteCalculator.calculateDuration(route);
            double expected = 5.0;
            assertEquals(expected, actual);
        }

        public void testRouteOnTheLine () {
            List<Station> actual = calculator.getShortestRoute(stationIndex.getStation("A"), stationIndex.getStation("C"));
            List<Station> expected = getList("A", "B", "C");
            assertEquals(expected, actual);
        }

        public void testRouteWithOneConnection () {
            List<Station> actual = calculator.getShortestRoute(stationIndex.getStation("A"), stationIndex.getStation("E"));
            List<Station> expected = getList("A", "B", "C", "D", "E");
            assertEquals(expected, actual);
        }

        public void testRouteWithTwoConnections () {
            List<Station> actual = calculator.getShortestRoute(stationIndex.getStation("A"), stationIndex.getStation("G"));
            List<Station> expected = getList("A", "B", "C", "D", "E", "F", "G");
            assertEquals(expected, actual);
        }
    }