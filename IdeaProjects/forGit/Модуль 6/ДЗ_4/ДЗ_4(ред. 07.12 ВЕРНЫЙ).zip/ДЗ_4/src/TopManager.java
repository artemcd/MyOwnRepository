import java.nio.file.attribute.UserPrincipalLookupService;

public class TopManager  implements Employee{
    private int salary;
Company company;
public TopManager(Company company) {
    this.company = company;
    getMonthSalary();
}
@Override
    public int getMonthSalary() {
    if (company.getIncome() >= 10000000) {
        salary = 240000;
    } else salary = 70000;
return salary;
}
}





