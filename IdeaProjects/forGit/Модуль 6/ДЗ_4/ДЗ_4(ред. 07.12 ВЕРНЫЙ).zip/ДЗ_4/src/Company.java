import java.util.*;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Company {
    private int profitOfCompany;

    {
        getIncome();
    }

    public int getIncome() { return profitOfCompany; }

    private ArrayList<Employee> employeeArrayList = new ArrayList<>();


    public void fire (Employee employee) {

        employeeArrayList.remove(employee);
        profitOfCompany -= employee.getProfit();
    }


    public void hire(Employee employee) {

            employeeArrayList.add(employee);
            profitOfCompany += employee.getProfit();
    }


    public void hireAll(List <Employee> list) {
        for(Employee employee : list) {
            hire(employee);
        }
    }



    public List<Employee> getTopSalaryStaff(int count) {

        List<Employee> topSalary = new ArrayList<>();

        if (count > employeeArrayList.size() || count <= 0) {
            System.out.println("Не верное число сотрудников");

        } else {
             topSalary = employeeArrayList;


            topSalary.stream()
                    .map(e -> e.getMonthSalary())
                    .sorted((o1, o2) -> -o1.compareTo(o2))
                    .limit(count)
                    .collect(Collectors.toList())
                    .forEach(System.out::println);
            System.out.println("Список из " + count + " сотрудников с самыми высокими ЗП составлен");

        }
        return topSalary;
    }


        public List<Employee> getLowestSalaryStaff(int count) {

         List<Employee> lowestSalary = new ArrayList<>();

        if (count > employeeArrayList.size() || count <= 0) {
            System.out.println("Не верное число сотрудников");

        } else {
            lowestSalary = employeeArrayList;

            Collections.sort(lowestSalary, Comparator.reverseOrder());
           lowestSalary = lowestSalary.subList(0, count);

            for (int number = 0; number < lowestSalary.size(); number++) {
                System.out.println(lowestSalary.get(number).getMonthSalary());
            }  System.out.println("Список из " + count + " сотрудников с самыми низкими ЗП составлен\n");
        }
        return lowestSalary;
    }
}