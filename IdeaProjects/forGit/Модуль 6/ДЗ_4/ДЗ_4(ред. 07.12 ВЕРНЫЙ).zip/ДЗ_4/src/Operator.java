public class Operator implements Employee {

    private final int salary;

    public Operator() {
        salary = 10000 + (int) (40000 * Math.random());
    }


    public int getMonthSalary() {
        {
            return salary;
        }

    }
}

