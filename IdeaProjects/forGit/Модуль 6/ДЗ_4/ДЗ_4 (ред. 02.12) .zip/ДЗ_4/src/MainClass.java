import java.util.ArrayList;
import java.util.List;

public class MainClass {

    public static void main(String[] args) {

        Company company = new Company();



        company.getTopSalaryStaff(10);

        company.getLowestSalaryStaff(1);
        company.hire(new Manager());

        company.getTopSalaryStaff(10);
    }
}



