import java.nio.file.attribute.UserPrincipalLookupService;

public class TopManager  implements Employee{
    private int salary = 70000;

public TopManager() {
    getMonthSalary();
}
@Override
    public int getMonthSalary() {
    if (new Company().getIncome() >= 10000000 ) {
        salary += 70000;
    } return salary;
}
}





