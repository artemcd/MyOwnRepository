import java.util.*;

public class Company {
    private int profitOfCompany;

    {
        getIncome();
    }

    public int getIncome() { return profitOfCompany; }

    private ArrayList<Employee> employeeArrayList = new ArrayList<>();
    private List<Employee> topSalary = new ArrayList<>();
    private List<Employee> lowestSalary = new ArrayList<>();


    public void fire (Employee employee) {

        employeeArrayList.remove(employee);
        profitOfCompany -= employee.getProfit();
    }


    public void hire(Employee employee) {

            employeeArrayList.add(employee);
            profitOfCompany += employee.getProfit();
    }


    public void hireAll(List <Employee> list) {
        for(Employee employee : list) {
            hire(employee);
        }
    }



    public List<Employee> getTopSalaryStaff(int count) {

        if (count > employeeArrayList.size() || count <= 0) {
            System.out.println("Не верное число сотрудников");

        } else {

            Collections.sort(employeeArrayList);
            topSalary = employeeArrayList.subList(0,count);

            for (int number = 1; number <= topSalary.size(); number++) {
                System.out.println(number + ". " + topSalary.get(number - 1).getMonthSalary() + " руб.");
            }
        }
        return topSalary;
    }


    public List<Employee> getLowestSalaryStaff(int count) {

        if (count > employeeArrayList.size() || count <= 0) {
            System.out.println("Не верное число сотрудников");

        } else {

            Collections.sort(employeeArrayList, Comparator.reverseOrder());
           lowestSalary = employeeArrayList.subList(0, count);

            for (int number = 1; number <= lowestSalary.size(); number++) {
                System.out.println(number + ". " + lowestSalary.get(number - 1).getMonthSalary() + " руб.");
            }
        }
        return lowestSalary;
    }
}


   /* public void showAllEmployee() {
        for (Object employee : employeeArrayList) {
            System.out.println(employee);
}
    }*/




/*  public  void getLowestSalaryStaff(int count) {
      List<Integer> list123 = new ArrayList<>(listOfSallary.values());
      Collections.sort(list123);
      if (count <= list123.size()) {
          for (int index = 0; index < count; index++) {
              System.out.println(list123.get(index));
          }
      } else {
          System.out.println("Вы ввели неверное число");
      }
  }
      public  void getTopSalaryStaff (int count) {
          List<Integer> list123 = new ArrayList<> (listOfSallary.values());
          Collections.sort(list123);
          if (count <= list123.size()) {
              for (int index = list123.size()-1; index > list123.size()-1 - count; index--) {
                  System.out.println(list123.get(index));
              }
          } else {
              System.out.println("Вы ввели неверное число");
          }*/






/*


 public void showAllSallary() {
        for (Map.Entry e : listOfSallary.entrySet()) {
            System.out.println(e.getKey() + " - " + e.getValue());


Map <String, Integer> allEmployee = new TreeMap <> ();
String profi;
int salary;
public void makeAllEmployee () {
    for (int count = 1; count != 251; count++) {
        int index = (int) (Math.random() * 3);
        if (index == 1) {
            profi = "saleManager";
        } else if (index == 2) {
            profi = "topManager";
        } else {
            profi = "operator";
        }
    }
}
    public static int saleManagerSalary() {
        int randomSalary = 15000 + (int) (Math.random() * 50000);
    }
}

*/

