public class Manager implements Employee {
    final int salary;
private int profit;
    public Manager() {

        salary = 50000 + (int) (50000 * Math.random()) + (profit * 5 / 100); ;
        profit = (int) (500000 * Math.random()) + 100000;
    }


    public int getProfit() {
        return profit;
    }

    @Override
    public int getMonthSalary() {
       return salary;
    }

    }




