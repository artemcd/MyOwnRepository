import java.util.ArrayList;
import java.util.List;

public class MainClass {

    public static void main(String[] args) {
        Company company = new Company();

        List <Employee> newListOfEmployee = new ArrayList<>();
        
        for(int i = 1; i <= 80; i++ ){ newListOfEmployee.add(new Manager()); }

        for(int i = 1; i <= 180; i++ ){ newListOfEmployee.add(new Operator()); }

        for(int i = 1; i <= 10; i++ ){ newListOfEmployee.add(new TopManager(company)); }

        company.hireAll(newListOfEmployee);
        company.getTopSalaryStaff(15);
        company.getLowestSalaryStaff(30);

        for (int i = 0; i < 40; i++) { company.fire(new Manager()); }

        for (int i = 0; i < 5; i++) { company.fire(new TopManager(company)); }

        for (int i = 0; i < 90; i++) { company.fire(new Operator()); }


        company.getTopSalaryStaff(15);
        company.getLowestSalaryStaff(30);

    }
}



