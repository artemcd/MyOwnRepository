public class Manager implements Employee{
 public String name;
 private  static int count = 0;

 public Manager(){
     count++;
 }

    public Manager (String name){
        this.name = name;
        count++;
    }
    @Override
    public int getMonthSalary() {
        int randomSalary = 50000 + (int)(100000*Math.random());
        return randomSalary;
    }
    public static int getCountOfEmployee()   {
        return count;
    }
}
