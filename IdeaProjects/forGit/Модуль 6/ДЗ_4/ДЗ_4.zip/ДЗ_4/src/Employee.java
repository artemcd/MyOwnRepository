public interface Employee  {
    int getMonthSalary ();
}
