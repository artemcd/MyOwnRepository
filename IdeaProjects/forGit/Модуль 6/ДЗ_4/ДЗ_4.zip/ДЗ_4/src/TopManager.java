public class TopManager implements Employee {
    public String name;
    private static int count = 0;

    public TopManager() {
        count++;
    }



    public static int getCountOfEmployee() {
        return count;
    }

    @Override
    public int getMonthSalary() {
        int fix = 50000 + (int)(100000*Math.random());
        int randomSalary;
        if (Company.getIncome() >= 10000000) {
            randomSalary = (int) (fix*1.5);
        }else{
            randomSalary = fix;
        }
        return randomSalary;
    }
}




   /* int randomSalary;
    public int getMonthSalary() {
        if (profit > 10000000)
             randomSalary = 75000;
    }else{
         randomSalary = 50000;
    }
        return randomSalary;    }
*/
