import java.util.Map;

public class MainClass {

    public static void main(String[] args) {
        Company company = new Company();

        company.hireAll(80,10,180);

    company.getLowestSalaryStaff(30);
    company.getTopSalaryStaff(15);
    company.fire(135);
        company.getLowestSalaryStaff(30);
        company.getTopSalaryStaff(15);
    }

    }

