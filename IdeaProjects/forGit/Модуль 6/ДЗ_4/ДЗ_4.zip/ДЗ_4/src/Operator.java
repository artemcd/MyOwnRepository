public class Operator implements Employee {

    public String name;
    private static int count = 0;
    public Operator(){}


        public int getMonthSalary () {
            int randomSalary = 35000;
            return randomSalary;
        }

        public static int getCountOfEmployee()   {
        return count;
        }
    }

