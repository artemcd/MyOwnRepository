import java.util.Map;

public class MainClass {

    public static void main(String[] args) {
        Company company = new Company();
        company.hireAll(new Manager(), 80);
        company.hireAll(new TopManager(), 10);

        company.hireAll(new Operator(), 180);

        company.getTopSalaryStaff(15);

        company.getLowestSalaryStaff(30);









    }

    }

