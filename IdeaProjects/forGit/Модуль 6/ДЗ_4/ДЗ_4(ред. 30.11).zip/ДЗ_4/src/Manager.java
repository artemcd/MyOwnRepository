public class Manager implements Employee {
    final int SALARY;
private int profit;
    public Manager() {

        SALARY = 50000 + (int) (50000 * Math.random());
        profit += (SALARY - 50000)*20;
    }


    public int getProfit() {
        return profit;
    }

    @Override
    public int getMonthSalary() {
       return SALARY;
    }

    }




