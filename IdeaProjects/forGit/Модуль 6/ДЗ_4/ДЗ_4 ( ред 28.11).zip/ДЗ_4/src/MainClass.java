import java.util.Map;

public class MainClass {

    public static void main(String[] args) {
        Company company = new Company();
        company.hireAll(80,10,180);
        company.getTopSalaryStaff(10);
        company.getLowestSalaryStaff(30);
        company.fire(135);
        company.getTopSalaryStaff(10);
        company.getLowestSalaryStaff(30);






    }

    }

