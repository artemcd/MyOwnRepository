public class MainClass {
    public static void main(String[] args) {
        Debit debit = new Debit(10000);
        debit.takeMoney(100);
        debit.getCount();
        debit.addMoney(50);
        debit.getCount();
        debit.takeMoney(100);
    }
}
