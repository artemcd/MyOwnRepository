import java.util.Date;

public class Debit extends BankCount {
    public Debit(int count) {
        super(count);
    }
Date date1;
    public void addMoney(int money) {
        if (money >= 0 ) {
        count += money;
        Date date = new Date();
        date1 = date;
    } else System.out.println("Нельзя положить на счёт отрицательное число.");
        }

    public void takeMoney (int money) {
        if (money <= count) {
            if (date1 != null) {
                Date date2 = new Date();
                long difference = date2.getTime() - date1.getTime();
                int days = (int) difference / (24 * 60 * 60 * 1000);
                if (days < 30)
                    System.out.println("Вы не можете снять деньги со счёта, т.к. с момента последнего пополнения прошло меньше месяца.");
                else {
                    count -= money;
                }
            } else {
                count -= money;
            }
        } else System.out.println("Превышен лимит.");
    }

    public int getCount() {
        System.out.println(count);
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}

