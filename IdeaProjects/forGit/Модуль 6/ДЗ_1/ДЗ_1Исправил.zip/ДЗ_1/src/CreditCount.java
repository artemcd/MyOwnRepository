public class CreditCount extends BankCount {
    public CreditCount(int count) {
        super(count);
    }

    public int getCount() {
        System.out.println(count);
        return count;
    }



    public void takeMoney(int money) {
        if ((money + (money / 100)) <= count) {
            count -= money - (money / 100);
        } else System.out.println("Превышен лимит.");
    }

    public void addMoney(int money) {
        if (money > 0) {
            count += money;
        } else {
            System.out.println("Нельзя положить на счёт отрицательную сумму.");
        }
    }
}
