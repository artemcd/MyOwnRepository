public class Fiz extends BankClients {
    public Fiz(int count) {
        super(count);
    }


}
