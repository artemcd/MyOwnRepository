public class WorkProgramm {

    public static void main(String[] args) {
ContactBook contactBook = new ContactBook();
contactBook.doIT();
    }
}
