public class EmailList {

    public static void main(String[] args) {
E_mail mailList1 = new E_mail();
mailList1.doIt();
    }
}
