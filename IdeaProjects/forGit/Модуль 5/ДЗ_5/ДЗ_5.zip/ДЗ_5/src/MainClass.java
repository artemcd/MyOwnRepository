public class MainClass {
    public static void main(String[] args) {
        TimeMashin timeMashin = new TimeMashin();
        timeMashin.start();

    }

}
