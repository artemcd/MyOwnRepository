import javax.print.DocFlavor;
import java.util.ArrayList;

public class MainClass {
   
    public static void main(String[] args) {
        TimeMashin timeMashin = new TimeMashin();
        timeMashin.start();

    }
}
