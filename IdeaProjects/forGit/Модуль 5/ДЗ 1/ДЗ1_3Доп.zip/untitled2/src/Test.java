public class Test {
    public static String[][] xForm = new String[5][6];

    public static void makeX() {
        int sizeX = 5, sizeY = 6;
        for (int i = 0; i < sizeX; i++) {
            for (int j = 0; j < sizeY; j++) {
                if (i < sizeX / 2 && j < sizeY / 2) {
                    if (i == j) xForm[i][j] = "X";
                    else xForm[i][j] = " ";
                } else if (i < sizeX / 2 && j >= sizeY / 2) {
                    if (i == (sizeY - 1) - j) xForm[i][j] = "X";
                    else xForm[i][j] = " ";
                } else if (i >= sizeX / 2 && j < sizeY / 2) {
                    if (j == (sizeX - 1) - i) xForm[i][j] = "X";
                    else xForm[i][j] = " ";
                } else if (i >= sizeX / 2 && j >= sizeY / 2) {
                    if ((sizeX - 1) - i == (sizeY - 1) - j) xForm[i][j] = "X";
                    else xForm[i][j] = " ";
                }
            }
        }
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(xForm[i][j]);
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        makeX();
    }
}
