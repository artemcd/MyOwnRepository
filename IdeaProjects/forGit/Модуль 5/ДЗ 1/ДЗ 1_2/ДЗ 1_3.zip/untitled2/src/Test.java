public class Test {
    public static String[][] xForm = new String[5][6];

    public static void makeX() {
        for (int i = 0; i < 3; i++) {
            for (int k = 0; k < 6; k++) {
                if (i - k == 0 || i + k == 5 || k - i == 1 || k + i == 4) {
                    xForm[i][k] = "x";
                } else {
                    xForm[i][k] = " ";
                }
            }
        }
        for (int i = 4; i > 2; i--) {
            for (int k = 0; k < 6; k++) {
                if (k - i == 1 || k + i == 4) {
                    xForm[i][k] = "x";
                } else {
                    xForm[i][k] = " ";
                }
            }
        }
        for (int f = 0; f < 5; f++) {
            for (int u = 0; u < 6; u++) {
                System.out.print(xForm[f][u]);
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        makeX();
    }
}
