
public class MyList {

    public static void main(String[] args) {

        BlockNote task = new BlockNote();
        task.compare();
    }


}

