
public class Loader
{
    public static void main(String[] args)
    {
        Cat cat = new Cat();
        Cat vasya = new Cat();
cat.feed(50.0);
vasya.feed(1000000.0);
cat.goToWC();

        System.out.println(cat.getStatus());
        System.out.println(cat.getWeight());
        System.out.println(vasya.getStatus());

        System.out.println("Количество котов: " + Cat.getCatCount());
    }
}