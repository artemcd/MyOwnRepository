public enum Color {
    BLACK,
    WHITE,
    BROWN
}
