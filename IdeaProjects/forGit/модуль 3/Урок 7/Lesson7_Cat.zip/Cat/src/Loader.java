
public class Loader {




    public static void main(String[] args) {
       Cat murka = new Cat(3000.0);
        Cat vasya = new Cat(murka);

        System.out.println(vasya.getWeight());
        System.out.println(murka.getWeight());

        vasya.feed(1000.0);

        System.out.println(vasya.getWeight());
        System.out.println(murka.getWeight());










        }
}