
public class Loader {

    public static void makeNewCat ( int i)
    {
        for (int a = 0; a < i; a++) {
            new Cat(1500.0);
        }
    }
    public static void main(String[] args) {
        makeNewCat(2);
        System.out.println(Cat.getCount());


    }
}