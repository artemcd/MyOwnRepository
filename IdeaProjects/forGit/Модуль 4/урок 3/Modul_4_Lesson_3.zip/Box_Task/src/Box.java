public class Box {

    public static void distributionOfBoxes (int allBoxes) {

        int numberOfContainers = 1;
        int numberOfBoxes = 1;



        for (int numberOfTrucks = 1; allBoxes > 0; numberOfTrucks++ ) {
            System.out.println("Грузовик " + numberOfTrucks + ":");

            for (int containersLimit = 1; containersLimit <= 12 && allBoxes > 0; containersLimit++, numberOfContainers++) {

                System.out.println("  Контейнер " + numberOfContainers + ":");

                for (int BoxLimit = 1; BoxLimit < 28 && allBoxes > 0;numberOfBoxes++, BoxLimit++, allBoxes--) {
                    System.out.println("    Ящик " + numberOfBoxes);
                }
            }
        }
    }


    public static void main(String[] args) {
        distributionOfBoxes(325);
    }
}

