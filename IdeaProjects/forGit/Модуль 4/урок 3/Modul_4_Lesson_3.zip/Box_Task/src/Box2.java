public class Box2 {


    public static void distributionOfBoxes(int numOfBoxes) {
        int numOfContainer = 0;
        int numOfBox = 0;

        for (int numOfTrack = 1; numOfBoxes > 0; numOfTrack++) {
            System.out.println("Грузовик " + numOfTrack + ":");
            do {
                numOfContainer++;
                System.out.println(" Контейнер " + numOfContainer + ":");
                do {
                    numOfBox++;
                    System.out.println(" Ящик " + numOfBox);
                    numOfBoxes--;
                }
                while (numOfBox % 27 != 0 && numOfBoxes > 0);
            }
            while (numOfContainer % 12 != 0 && numOfBoxes > 0);
        }
    }

    public static void main(String[] args) {
        distributionOfBoxes(350);
    }
}


