
public class Loader {
    public static void main(String[] args) {
        String text = "Вася заработал 5000 рублей, Петя - 7563 рубля, а Маша - 30000 рублей";
        int vasyaIndexStart = (text.indexOf('л')) + 2;
        int vasyaIndexEnd = (text.indexOf(',')) - 7;

        int petyaIndexStart = (text.indexOf('-')) + 2;
        int petyaIndexEnd = (text.lastIndexOf(',')) - 6;

        int mashaIndexStart = (text.lastIndexOf('-')) + 2;
        int mashaIndexEnd = (text.lastIndexOf('р')) - 1;

        int vasyaSum = Integer.parseInt(text.substring(vasyaIndexStart, vasyaIndexEnd));
        int petyaSum = Integer.parseInt(text.substring(petyaIndexStart, petyaIndexEnd));
        int mashaSum = Integer.parseInt(text.substring(mashaIndexStart, mashaIndexEnd));
        System.out.println("Сумма всех ЗП:" + (vasyaSum + petyaSum + mashaSum));
    }
}