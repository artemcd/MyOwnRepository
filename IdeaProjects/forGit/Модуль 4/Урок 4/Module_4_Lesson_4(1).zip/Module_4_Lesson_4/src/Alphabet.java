public class Alphabet {

    public static void alpha() {
        String abc = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for (int index = 0; index < abc.length(); index++){
            char letter = abc.charAt(index);
            int code = (int) letter;
            System.out.println(letter + " = " + code);
            }
        }

    public static void main(String[] args) {
        alpha();
    }

    }

