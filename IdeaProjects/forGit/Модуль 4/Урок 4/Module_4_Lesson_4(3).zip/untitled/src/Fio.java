import java.util.Scanner;

public class Fio {

    public static void main(String[] args) {

        Scanner personFio = new Scanner(System.in);
        System.out.println("Введите свои Имя Фамилия Отчество:");
        String inFio = personFio.nextLine();

        String NewInFio = inFio.trim();

        String lastName = NewInFio.substring(0, (NewInFio.indexOf(" ")));
        String fatherName = NewInFio.substring((NewInFio.lastIndexOf(" ")), NewInFio.length());
        String name = NewInFio.substring((NewInFio.indexOf(" ")), NewInFio.lastIndexOf(" "));


        System.out.println("Фамилия: " + lastName);
        System.out.println("Имя: " + name);
        System.out.println("Отчество: " + fatherName);
    }
}
